const awsmobile = {
  aws_project_region: 'us-east-2',
  aws_user_pools_id: 'us-east-2_FyHLtOhiY',
  aws_user_pools_web_client_id: '1hdn8b19ub2kmfkuse8rsjpv8e',
  oauth: {
    domain: 'us-east-2fyhltohiy.auth.us-east-2.amazoncognito.com',
    scope: ['email', 'openid'],
    redirectSignIn: 'https://d3rho4lut2re5r.cloudfront.net/',
    redirectSignOut: 'https://d3rho4lut2re5r.cloudfront.net/',
    responseType: 'code',
  },
};
export default awsmobile;

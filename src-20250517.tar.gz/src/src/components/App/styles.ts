import { Box, styled } from '@mui/material';

export const AppContainer = styled(Box)`
  user-select: none;
`;

export interface CounterProps {
  value: number;
}

export interface ButtonProps {
  onClick?: () => void;
}

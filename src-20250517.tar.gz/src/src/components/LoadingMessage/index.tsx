import { Box } from '@mui/material';

export const LoadingMessage = () => {
  return <Box id="loading">Loading...</Box>;
};
